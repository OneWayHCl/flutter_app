//
//  HybridViewController.swift
//  Runner
//
//  Created by luckysmg on 2021/5/21.
//

import UIKit

//第二个tab页面（临时占位，还没做）
class HybridViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.red
    }
}
