package com.idlefish.flutterboost.containers;

enum LifecycleStage {
    ON_CREATE,
    ON_START,
    ON_RESUME,
    ON_PAUSE,
    ON_STOP,
    ON_DESTROY
}