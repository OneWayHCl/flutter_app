package com.idlefish.flutterboost;

/**
 * The interface to remove the EventListener added in list
 */
public interface ListenerRemover {
    void remove();
}
